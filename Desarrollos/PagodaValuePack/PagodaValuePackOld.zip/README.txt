Gerbers and drill files are in millimeters, 4 integer 4 decimal format.
The PCB shape can be checked with PCB-3D-PICTURE.png
