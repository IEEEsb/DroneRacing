Load the Pagodas.PrjPcb project
Modify whatever you want
Run "GerberGenerator.OutJob" (Settings folder on project) and Generate Content
Run cleanup_rename.bat from ProjectOutputs folder (it cleans the names and removes all unneccesary files)