Load the Pagodas.PrjPcb project
Modify whatever you want
Run "GerberGenerator.OutJob" (Settings folder on project) and Generate Content
Run cleanup_rename.bat from ProjectOutputs folder (it cleans the names and removes all unneccesary files)

Drill files for ValuePacks are generated both in separate plated and not plated files and as a combined file.

Use the separate files (Drills_Plated.TXT and Drills-NonPlated_NPTH.TXT) and delete the combined file (Drills_Combined.TXT) if your manufacturer supports separate drill files, or keep only the combined
file if your manufacturer prefers a single drill file.

Gerber and drill files are in metric 4,4 format. Some gerber visualizers will have trouble with this,
mostly with drill files. If your drills show as blob in the lower left corner, tell your visualizer
that they are in metric 4,4 format and they should be fixed.
This is not an issue for PCB manufacturers, they'll make your boards just fine.