The PCB needs internal milling, as indicated on GML layer.
Please check RHCP-PANEL.png picture to see how the board 
should look like if there is any doubt.